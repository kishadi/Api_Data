from pyspark.sql.functions import col,explode
from pyspark.sql.types import *
from urllib import request

def _extract_data(spark,config):
    urldata = request.urlopen(config.get("Source")).read().decode("utf8")
    rdd = spark.sparkContext.parallelize([urldata])
    raw_df = spark.read.json(rdd)

    return raw_df

def _transform_data(spark, raw_df):
    df1 = raw_df.withColumn("results", explode(col("results")))
    flattened_df = df1.select(col("nationality"),
                        col("results.user.cell"),
                        col("results.user.dob"),
                        col("results.user.email"),
                        col("results.user.gender"),
                        col("results.user.location.*"),
                        col("results.user.md5"),
                        col("results.user.name.*"),
                        col("results.user.password"),
                        col("results.user.phone"),
                        col("results.user.picture.*"),
                        col("results.user.registered"),
                        col("results.user.salt"),
                        col("results.user.sha1"),
                        col("results.user.sha256"),
                        col("results.user.username"),
                        col("seed"),
                        col("version"))

    return flattened_df


def _load_data(config, _transformed_df):
    f = config.get("Target") + "/target_data"
    _transformed_df.write.format("csv").\
        mode("overwrite").option("header","true").\
        save(f)

    _transformed_df.write.format("jdbc").\
        option("url",config.get("db.dburl")).\
        option("dbtable",config.get("db.dbtable")).\
        option("user",config.get("db.username")).\
        option("password",config.get("db.password")).save()

def run_job(spark, config):
    _load_data(config, _transform_data(spark,_extract_data(spark, config)))